<?php

namespace Paylike\Exception;

/**
 * Class ApiConnection
 *
 * @package Paylike\Exception
 */
class ApiConnection extends ApiException
{

}
